﻿namespace OpenXLiveAdTest
{
    public partial class FullScreenPage
    {
        public FullScreenPage()
        {
            InitializeComponent();
        }
    }
}