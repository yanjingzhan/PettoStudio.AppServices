﻿using System.Windows;

namespace OpenXLiveAdTest
{
    public partial class InterstitialPage
    {
        public InterstitialPage()
        {
            InitializeComponent();
        }
    }
}