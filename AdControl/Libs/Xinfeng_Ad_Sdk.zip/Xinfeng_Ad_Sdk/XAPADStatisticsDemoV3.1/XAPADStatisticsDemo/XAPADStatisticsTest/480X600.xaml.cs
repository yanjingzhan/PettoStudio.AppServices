﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;

namespace XAPADStatisticsTest
{
    public partial class _480X600 : PhoneApplicationPage
    {
        public _480X600()
        {
            InitializeComponent();
        }
    }
}